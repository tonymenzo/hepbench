# Blind usability rating (pre-grade)

8 — smooth: the sandbox, background job execution, and Python/Pythia8/matplotlib toolchain all worked without friction; the only real snags were physics/code bugs I introduced myself (missing 4π² phase-space factor, stale Pythia sigmaGen snapshot), not tooling limitations.