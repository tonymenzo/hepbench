# Blind usability rating (pre-grade)

8 — smooth overall: the sandbox tools (Bash, Read/Write/Edit) were sufficient for a heavy numerical physics pipeline, and the main friction was self-inflicted (needing to derive/validate QFT matrix elements carefully and catching two real normalization bugs via cross-checks) rather than tooling limitations.