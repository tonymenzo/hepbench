# Blind usability rating (pre-grade)

8 — the physics-first tool chain (ProductionSpectrum → HarvestForwardFlux → MesonDecayToLLP → DecayInVolumeVsCoupling) composed cleanly with good error messages (e.g. the two-track kinematic rejection) and useful diagnostics (grid_diagnostic, n_strata_advice), with only minor friction from large intermediate file sizes and having to hand-derive the g²-portal reduced widths myself.

---

## Audit against the grade

**yield_distance (FAIL)** and **contour_upper (FAIL)** trace to the same root cause, and it's methodology, not tool friction: I raised `MesonDecayToLLP`'s `n_strata` from 16→64 for the rare charm/charmonium parents (D, Dₛ, J/ψ, ψ(2S)) but left the abundant parents (K, ρ, ω, φ(1020)) at the default 16. K has a *finite* `ctau_parent_m` (3.712 m) and dominates the flux at the low masses that carry almost the whole graded reach — exactly the parent whose decay-length stratification sets the strong-coupling (lifetime-limited) edge the grader flagged as "sample-starved." ρ/ω/φ/J/ψ/ψ(2S) all have `ctau_parent_m=0.0` (prompt), so `n_strata` is a no-op for them — raising it there was free but did nothing for the metric that failed. I optimized cost against the wrong axis: I read the tool's own advisory ("raising it only for the small heavy-flavor fluxes is cheap") as "the small fluxes are where it matters" rather than "the small fluxes are where it's cheap" — and conflated cheapness with necessity, so I skipped the one channel (K) that was both affordable-ish and actually load-bearing for the upper edge.

The single tool/doc change most likely to have prevented this: make `MesonDecayToLLP`'s `n_strata_advice` **parent-specific and quantitative** — report each parent's weight share at each mass alongside its `ctau_parent_m`, so a prompt parent (ρ/ω/φ) doesn't get the same boilerplate "raise n_strata" text as K, which actually needed it. I'd also nudge my earlier usability score down slightly, from 8 to **7**: the tool exposed the exact right knob and quoted precise convergence numbers, but the generic, identical advisory text across all 8 calls actively invited the wrong prioritization on a mixed prompt/finite-lifetime parent set.

## Tool critique

**1. Confusing / error-prone**
- `MesonDecayToLLP`'s `n_strata_advice` string is byte-identical across every parent call regardless of whether `ctau_parent_m` is 0 (prompt — stratification is a complete no-op) or finite (K: 3.712 m). Nothing in the message says "this doesn't apply to you" for prompt parents, so the signal that matters (K needs it, ρ/ω/φ don't) is invisible unless you manually diff `ctau_parent_m` across the eight JSON blobs yourself.
- `DecayInVolumeVsCoupling`'s `grid_diagnostic.band_bracketed` reads like an accuracy signal but is purely a grid-*range* check (is `g_grid` wide enough), not a precision check. I initially treated "bracketed" as "trustworthy," which it isn't — the edge can be bracketed and still be built from an under-stratified flux.

**2. Behavior vs. documentation mismatch**
- Nothing in the pipeline surfaces, at the `DecayInVolumeVsCoupling` stage, that the *upstream* `llp_*.jsonl` file it's reweighting was generated at `n_strata=16`. The two tools' diagnostics don't cross-reference, so a caller can get a clean-looking `grid_diagnostic` on top of an insufficiently-sampled flux with no warning at the point where it actually gets consumed.

**3. Concrete changes**
- Make the `n_strata_advice` conditional: suppress it (or replace with "prompt parent — n_strata has no effect") when `ctau_parent_m==0`; when finite, include that parent's fractional weight contribution at each mass so the caller can see "K carries 80% of the weight at m=0.06 and has a real decay length → raise this one" versus "ψ(2S) carries 0.02% → low priority regardless of cost."
- Have `DecayInVolumeVsCoupling` propagate a precision flag when a non-trivial fraction of `sum_weights` near the strong-coupling peak comes from a low-`n_strata` input file, since that's precisely the information needed to decide whether to trust the upper edge before reporting it.
- Default `n_strata` could scale with a parent's flux-weight share rather than being flat across wildly different physics roles (K vs. ψ(2S)).

**4. Missing capability**
- No convergence-check tool: something like "run this reach point at two `n_strata` values and report the actual delta on *my* edge" would have let me verify the quoted 4.8%/2.1%/1.0% figures against my specific geometry/flux instead of trusting a generic number computed elsewhere. That would have caught the K under-sampling empirically rather than requiring me to reason about it correctly by hand.