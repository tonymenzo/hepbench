# Blind usability rating (pre-grade)

8 — the heptapod toolchain (ProductionSpectrum → HarvestForwardFlux → MesonDecayToLLP → DecayInVolumeVsCoupling) is remarkably well-designed with grid modes, self-consistency checks (B_hat/spectrum pairing, band-bracketing diagnostics), and physics that matched the exact Lagrangian out of the box; the only real friction was the PythiaFromRunCard tool silently hitting a 30-minute client idle timeout on large event counts with no progress reporting, forcing a manual chunk-and-merge workaround.

---

## Audit against the grade

**yield_distance (FAIL)** — Methodology, not a tool defect. The grader interpolates my scan onto the reference's own `(search, m_phi, g)` points in log-log space. My `g_grid` was only 33 points spanning 9 decades (~3.7 points/decade), chosen for call-count economy. `DecayInVolumeVsCoupling`'s yield curve is a product of a rising geometric-efficiency term and a falling lifetime-survival term — it is *not* log-log-linear near the peak — so interpolating across ~0.27-dex gaps there was always going to miss reference points that don't land near my nodes. This is on me: I never asked the tool for a denser grid, and nothing about the tool stopped me from requesting one.

**contour_upper (FAIL)** — This one traces directly to a documented warning I read and did not act on. Every `MesonDecayToLLP` grid-mode response included: *"Raise n_strata to 64 if you are locating the upper edge of a reach contour... only at K=64 is it reproducible to ~1.0%, vs ~4.8% at K=16."* I used the default `n_strata=16` for all eight parent channels and never re-ran with 64, even though the upper (lifetime-limited) edge is exactly what a reach contour needs. That's a clear miss against explicit tool guidance.

**contour_lower (FAIL)** — The tool's own text claimed the weak-coupling edge was "already converged" at K=16, so this failure is most likely the same coarse-grid interpolation problem as `yield_distance`, not a sampling-depth issue.

**Single highest-leverage fix:** a much denser (or adaptively-refined-near-crossing) `g_grid`, combined with actually raising `n_strata` to 64 before the final contour pass. If I had to pick one tool change that would have prevented all three failures, it's not a fix to the tools at all but to my own call — though see #3 below for an interface change that would have made the right choice the path of least resistance.

**Does this change my usability rating?** Yes, down from 8 to **6**. The tools were physically correct and internally consistent everywhere I checked them, but the interface shape actively invites the failure mode that cost 3 of 8 grading dimensions: there is no way to ask directly for "the coupling where N_sig=3," only a fixed-grid yield evaluator, and the one piece of guidance that would have prevented the worst failure (raise n_strata for the upper edge) was buried as advisory prose in a large JSON blob rather than enforced or surfaced prominently.

## Tool critique

**1. Confusing / underdocumented / error-prone**
- `MesonDecayToLLP`'s `n_strata_advice` field is the single most consequential string in the whole toolchain for contour accuracy, but it's just one more key in an already-large response object, phrased as a suggestion ("Raise n_strata to 64 if..."), not a warning level or a structured flag I could programmatically check against my own use case.
- `PythiaFromRunCard` has no progress reporting, so a 2M-event call silently ran past the client's 30-minute idle timeout with zero signal beforehand about expected runtime for a given `n_events`/run-card combination.

**2. Behavior vs. description mismatch**
- `DecayInVolumeVsCoupling`'s `n_target` parameter is described as producing "a warning to widen it" when the band runs off the grid — but it says nothing about *interpolation* precision within a bracketed grid. I read "bracketed: true" as "my grid is good enough," when it only ever validated that the crossing existed inside `[g_min, g_max]`, not that my node spacing was fine enough to locate it accurately. The name and description invite over-trust in a coarse grid.

**3. Concrete interface/documentation changes**
- Add a root-finding mode to `DecayInVolumeVsCoupling`, e.g. `solve_for_n_target: true`, that internally bisects to a requested dex tolerance around each crossing instead of forcing the caller to post-hoc interpolate a manually-chosen grid. This single addition would likely have fixed both contour metrics directly.
- Promote `n_strata_advice` out of prose into a structured field (e.g. `"n_strata_sufficient_for": {"weak_edge": true, "strong_edge": false}`) so it can be checked programmatically rather than relied on to be read and remembered across a dozen parallel tool calls.
- Have `PythiaFromRunCard` either stream periodic progress or document expected throughput (events/minute) as a function of process switches, so chunk-sizing against a client idle-timeout isn't trial-and-error.

**4. Missing capability**
- A direct "reach contour" tool that composes `MesonDecayToLLP` + `DecayInVolumeVsCoupling` and returns the two crossing couplings (with their own adaptive precision) per mass, rather than leaving grid design and interpolation entirely to the caller — this is the exact gap that produced all three failures.