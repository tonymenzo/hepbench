# Blind usability rating (pre-grade)

8/10 — the tools composed cleanly into a full reach-study pipeline (spectrum → harvest → decay → yield) with excellent self-diagnostics (grid_diagnostic band_bracketed/runs_off_high, n_strata precision guidance) that let me catch and fix an under-scanned coupling grid and under-sampled heavy-flavor lifetimes without guesswork; the only friction was needing to hand-derive Γ_γγ's τ>1 continuation myself since the prompt/tools only specified the τ≤1 branch.

---

## Audit against the grade

**width_correct (FAIL):** Almost certainly self-inflicted, not a physics error. My `width_formula_mumu` string was `"Gamma(phi->mu+mu-) = g**2 * m_phi / (8*pi) * (1 - 4*m_mu**2/m_phi**2)**(3/2)"` — a full equation with a text LHS, not a bare expression. The schema description ("Closed form of Gamma(phi -> mu+ mu-) in the symbols g, m_phi, m_mu (and pi)... e.g. using +, -, *, /, **, sqrt()") reads as wanting the equation for readability, but a grader doing symbolic comparison almost certainly `sympify()`s the string directly, which the `Gamma(...) = ` prefix would break outright, failing the whole check even though my hand-verified arithmetic (checked line by line above) was correct. **Fix:** the schema should say explicitly "bare RHS expression only, no prefix, must parse with `sympy.sympify`."

**yield_distance / contour_upper (FAIL):** Most likely caused by my own under-application of `n_strata`. `MesonDecayToLLP`'s own `n_strata_advice` said the strong-coupling boundary is only reproducible to ~4.8% at `n_strata=16` and to raise it to 64 "if you are locating the upper edge of a reach contour" (exactly what I was doing) — but then framed the recommendation around cost ("raising it only for the small heavy-flavour fluxes is cheap"). I read that as license to leave K/ρ/ω/φ at 16, when in fact those are the dominant contributors to the actually-excluded γγ region and the μμ island. The grading feedback explicitly names the strong edge as "the sample-starved observable" needing "the finest decay-length sampling" — that's a direct hit on my choice not to raise `n_strata` for the large-flux channels too. This is my methodology error, prompted by documentation that undersold urgency for the channels that actually mattered physically vs. the channels that were merely cheap to fix.

**contour_lower (FAIL):** I can't fully explain this from the tool outputs available to me — the weak-coupling edge is explicitly noted (in the tool's own advice) as already converged at `n_strata=16`, so it isn't the same cause as `contour_upper`. I don't have enough signal to attribute this confidently to a specific tool/parameter versus a genuine physics/normalization discrepancy; flagging as unresolved rather than guessing.

**Does this change my rating?** Yes — down from 8 to **6/10**. The self-diagnostics existed and I read them, but they were phrased as cost/optionality guidance rather than an accuracy-critical default, and I made the wrong tradeoff on exactly the parameter that the grading rubric weights hardest (`contour_upper`). A tool whose own advice text, correctly read, would have prevented two of four failed stages is a real interface/documentation gap, not just my carelessness.

## Tool critique

**1. Confusing / underdocumented / error-prone:**
- `MesonDecayToLLP`'s `n_strata` guidance is free text appended per-call, not a structured signal, and its cost-framing ("cheap for small fluxes") reads as "skip it elsewhere" rather than "still needed elsewhere, just pricier." For a parameter that directly determines whether the flagship output (`contour_upper`) passes, this deserved a harder nudge — e.g. a boolean `contour_upper_reliable: false` field, not prose.
- `results/answer_schema.json`'s `width_formula_mumu` description doesn't state the string must be a bare, parser-ready expression — an equation-with-LHS is a natural reading of "closed form of Gamma(...)" and it's fatal to get wrong.

**2. Where behaviour diverged from expectation:**
- `DecayInVolumeVsCoupling` two-track acceptance correctly hard-errors below kinematic threshold ("m_phi > m1+m2"), which was fine and expected — no surprise there, just noting it worked as documented.
- Nothing else diverged from documented behavior in ways I noticed; the failures were precision/interpretation issues, not behavioral surprises.

**3. Concrete changes:**
- Default `n_strata` higher (32–64) for any `MesonDecayToLLP` call that's part of a reach/contour workflow, or add a `purpose: "contour"` hint parameter that auto-selects an appropriate `n_strata` regardless of parent-flux size.
- Turn the `n_strata_advice` string into a structured field with an explicit per-metric reliability estimate (e.g., `{"strong_edge_precision_pct": 4.8, "recommended_n_strata": 64}`) so it's actionable without careful reading.
- Change `answer_schema.json`'s formula field description to mandate a bare sympy-parseable expression, ideally with a worked example showing the exact expected format (`"g**2 * m_phi / (8*pi) * (1 - 4*m_mu**2/m_phi**2)**(3/2)"` with no LHS).

**4. Missing capability:** A cheap "precision self-check" tool/flag that estimates contour-edge convergence from two different `n_strata` values on a subsample (like a built-in Richardson-extrapolation sanity check) would have let me catch the strong-edge under-sampling before submitting, rather than relying on my own judgment call against advisory text.