# Blind usability rating (pre-grade)

8 — the reach-chain tools (ProductionSpectrum → HarvestForwardFlux → MesonDecayToLLP → DecayInVolumeVsCoupling) compose cleanly with self-consistent conventions (g²-stripping, B_hat/spectrum pairing, weight propagation) and good guardrails (kinematic-closure errors, threshold warnings, manifest echoes), with only minor friction from verbose per-call JSON and having to hand-derive/track partial widths externally before feeding them back in.

---

## Audit against the grade

**contour_upper FAIL** is the one stage to explain. This edge is the strong-coupling/lifetime-limited boundary, set by parents decaying in the thin sliver of their decay-length distribution just upstream of the z=50 m shield front. `MesonDecayToLLP`'s `n_strata` parameter description says this explicitly and quantifies it: "at K=16 the yield and weak-coupling boundary are reproducible to ~0.4%... The STRONG-coupling boundary is harder... ~4.8% at K=16, ~2.1% at K=32, ~1.0% at K=64. Raise K if that boundary matters." The inherited LLP flux I built on top of (`work/llp/*/meson_decay_manifest.json`) was generated with `n_strata=32`, and I reused it rather than regenerating at `n_strata=64` before running the final yield scan.

That's a **methodology failure, not a tool or documentation gap** — the tool told me exactly what to do, with numbers, in the parameter's own docstring. I read it, registered that 32 was already better than the default, and didn't push further given I was resuming someone else's pipeline and optimizing for turnaround. The single change that would have prevented it: re-run `MesonDecayToLLP` in grid mode with `n_strata=64` for the eight parent channels before the final `DecayInVolumeVsCoupling` pass — a pure "spend more compute" fix I had the information to make and didn't.

This does nudge my usability rating down slightly, from 8 to **7**: the *default* (`n_strata=16`) is a footgun for exactly the observable the whole reach-chain exists to compute, and nothing in `DecayInVolumeVsCoupling`'s output actively flags "your strong-edge sampling is thin here" — the accuracy guidance lives only in a different tool's parameter description, easy to satisfy-and-forget once you've bumped it once.

## Tool critique

**1. Confusing / underdocumented / error-prone**
- Nothing was actually underdocumented — the `n_strata` docstring is a model of good practice (quantified error at three settings, tied to the specific physics observable it affects). The friction is *placement*: that guidance lives in `MesonDecayToLLP`, but its consequence only shows up three tools later in `DecayInVolumeVsCoupling`'s strong-coupling edge, with no cross-referencing diagnostic at the point of consumption.
- `two_track` acceptance correctly rejects kinematically-closed `(m_phi, daughter_masses)` combinations with a clear, actionable error ("use acceptance='photon'/'none'") — this cost me three wasted calls (m=0.06, 0.12, 0.18) before I precomputed the 2·mμ threshold myself. Not a bug, just a case where the tool could have let me pass a mass list and skip closed ones rather than hard-erroring per call.

**2. Where behavior differed from expectations**
- None. `DecayInVolumeVsCoupling`'s `partial_widths_ref_gev`/`visible_channels` mechanism, the `events_paths_glob` concatenation, and the `grid_diagnostic.band_bracketed` check all behaved exactly as documented. `grid_diagnostic` does confirm the *g-grid range* was adequate — it does not, and doesn't claim to, say anything about *event-sampling* adequacy at the strong edge, so I can't fault it for not catching the real issue.

**3. Concrete changes**
- Raise `MesonDecayToLLP`'s default `n_strata` from 16 to something closer to 64, or make `DecayInVolumeVsCoupling` echo back the `n_strata` its input LLP records were generated with (it's in the upstream manifest, not the flux records themselves) alongside a rule-of-thumb note near `grid_diagnostic` like "strong-edge accuracy scales with upstream n_strata; see MesonDecayToLLP docs" — surfacing the dependency at the point where its absence actually bites.
- A thin orchestrator over the four-tool chain (spectrum → harvest → decay → yield) for the common case, defaulting to the higher-precision `n_strata`, would remove an entire class of "I reused someone else's intermediate artifact at a lower setting" mistakes like this one.

**4. Missing capability**
- A sampling-adequacy diagnostic specifically for the near-absorber decay-length sliver — e.g., effective sample count or a bootstrap error estimate on the strong-coupling edge — would have let me catch this before submitting rather than after grading.