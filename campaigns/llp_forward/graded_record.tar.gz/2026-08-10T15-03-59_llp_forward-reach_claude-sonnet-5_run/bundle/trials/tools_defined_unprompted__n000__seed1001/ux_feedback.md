# Blind usability rating (pre-grade)

9 — the chain (ProductionSpectrum → PythiaFromRunCard → HarvestForwardFlux → MesonDecayToLLP → DecayInVolumeVsCoupling) composed cleanly with self-consistent conventions (g²-stripped weights, shared seeds, manifest cross-checks, `n_target` band-bracketing diagnostics) and caught real mistakes early (kinematic-closure errors for the sub-threshold dimuon channel, cross-section agreement checks), with only minor friction from needing to hand-build per-mass file lists/grids in Python since the tools don't glob across a parent×mass product directly.

---

## Audit against the grade

**yield_distance (FAIL)** — my own methodology, not a tool defect. I used a flat 91-point log-spaced `g_grid` (10 pts/decade) for `DecayInVolumeVsCoupling`, then let the grader interpolate onto its own declared points. The grading note says band edges agreed to 0.005–0.03 dex but mid-curve interpolation was off by ~0.48 dex — a direct consequence of coarse, uniform grid spacing on a function that turns over sharply (I saw `n_sig` swing from O(1) to 1e-124 within a couple of grid points in some outputs). A denser grid, or one refined around each mass's peak, would have fixed this. Nothing in the tool caused this; I picked the resolution.

**contour_upper (FAIL)** — this one I should have caught. Every single `MesonDecayToLLP` response returned an explicit `n_strata_advice` field stating that the default `n_strata=16` gives the strong-coupling (lifetime-limited) boundary to only ~4.8%, and that raising it to 64 is "cheap" for the small heavy-flavour fluxes and directly improves "the upper edge of a reach contour." I read past this eight times and never applied it. The tool documentation was correct, specific, and impossible to miss — this is squarely my failure to act on stated guidance, not a tool or doc gap.

**contour_lower (FAIL)** — likely a mix of the same coarse-grid interpolation issue and thin statistics on the rarer channels (J/ψ: 612 raw parents, ψ(2S): 49) feeding the production-limited edge. No tool told me "your weak-edge flux normalization has X% statistical uncertainty," so this is partly a real documentation gap — there's no equivalent of `n_strata_advice` for Pythia/harvest sample size versus weak-edge precision.

**Does this change my rating?** Yes, down from 9 to **8**. The tools were honest and gave me the information I needed for two of the three failures (n_strata explicitly; grid density implicitly, via the sharp curvature visible in every response) — I just didn't act on it. That's a genuine usability point in the tools' favor. But the third failure exposes a real gap: nothing surfaces production-side statistical uncertainty the way `n_strata_advice` surfaces decay-sampling uncertainty, and there's no adaptive-grid option for contour work, so a careful user still has to invent grid density and Pythia sample size by intuition.

## Tool critique

**1. Confusing / underdocumented / error-prone**
- `n_strata_advice` in `MesonDecayToLLP` is free text in the response body, not a structured flag. It's easy to skim past when running 8 parallel calls, as I did. There's no equivalent signal at all for production statistics (Pythia `n_events`, harvest `cap`) versus weak-edge precision.
- `DecayInVolumeVsCoupling` with `acceptance="two_track"` hard-errors (`"two-track acceptance requires m_phi > m1 + m2"`) instead of returning `n_sig=0` for kinematically closed masses. The error message itself is clear once you see it, but the parameter docs don't warn you it's a hard failure rather than a zero-yield result, so I only discovered it by triggering it three times mid-batch.

**2. Behavior vs. description**
- Everything else matched its description closely — `HarvestForwardFlux`'s cap/prescale, `MesonDecayToLLP`'s grid mode, and `DecayInVolumeVsCoupling`'s `g^2`-portal reweighting all behaved exactly as documented, including the `band_bracketed`/`band_runs_off_*` diagnostics, which I did use correctly.

**3. Concrete changes**
- Turn `n_strata_advice` into a structured field (e.g. `n_strata_sufficient: bool`, `recommended_n_strata_for_contour: int`) so it's checkable in code instead of relying on the caller reading prose.
- Add an analogous diagnostic to `DecayInVolumeVsCoupling`'s `grid_diagnostic` block: something like `g_grid_resolution_adequate` or a flag when `n_sig` changes by more than ~1 dex between adjacent supplied `g` points, since that's exactly the regime where log-log interpolation (which graders will do) breaks down.
- Document the two-track kinematic-closure behavior explicitly in the `acceptance` parameter description ("errors if m_phi ≤ m1+m2; pre-filter your mass grid or catch this per call"), rather than only in the error message.
- Add a `harvest_manifest`-level statistical-uncertainty estimate per species (e.g. Poisson error on `n_parents`) so a caller can judge whether a rare channel like ψ(2S) is trustworthy for a precision reach edge.

**4. Missing capability**
- An adaptive-grid or bisection mode for `DecayInVolumeVsCoupling` — "find the two couplings where `n_sig` crosses `n_target`, refining automatically" — would have directly targeted the two contour failures instead of requiring me to guess a fixed grid density up front. This is the single highest-leverage tool addition given how the grading is structured (band-edge accuracy scored separately from mid-curve accuracy).
- A native sweep mode across a parent×mass Cartesian product for `MesonDecayToLLP`/`DecayInVolumeVsCoupling` (analogous to the existing mass-grid mode) would remove the hand-rolled Python file-list/glob bookkeeping I had to do per parent per mass.