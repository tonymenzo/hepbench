# Blind usability rating (pre-grade)

8 - The domain tools covered the full physics pipeline cleanly with good provenance, though dense JSON tool calls and manual orchestration across many masses/channels added some friction.

---

Knowing the grade, I’d lower the usability rating from **8 to 7**. The tools covered the pipeline, but the accuracy-critical sampling choices were too easy to under-specify.

## Audit Of Failed Stages

`yield_distance`: Mostly my methodology, but enabled by tool friction. I used `HarvestForwardFlux cap=20000` and `MesonDecayToLLP n_strata=16`, prioritizing runtime over accuracy. The `MesonDecayToLLP` description did warn that strong-coupling boundaries improve with larger `n_strata`, but there was no accuracy-targeted preset or diagnostic tying `n_strata`, capped flux size, and expected yield-distance error together.

`contour_lower`: Mostly my methodology. The lower edge is production-limited, so my capped parent samples and finite Pythia statistics likely dominated. The relevant friction was `HarvestForwardFlux cap`: it preserves normalization but makes it easy to reduce phase-space statistics without a downstream warning that contour/yield accuracy may degrade.

`contour_upper`: Tool/documentation friction plus my methodology. `MesonDecayToLLP n_strata` is the key parameter; I used 16 despite the tool warning. The tool’s note says the strong edge is harder, but the pipeline did not enforce or recommend a task-appropriate value after seeing a reach scan. A stronger warning or auto-refinement recommendation would likely have prevented this.

The single most useful change: add a **reach-accuracy preset or convergence helper** that recommends or automatically reruns `MesonDecayToLLP` with higher `n_strata` and less aggressive caps for contour work, especially after `DecayInVolumeVsCoupling` detects an exclusion band.

## Tool Critique

1. **Confusing, underdocumented, or error-prone**

- `HarvestForwardFlux cap`: The cap is statistically compensated, which is correct, but it is easy to treat it as “free” because summed weights are preserved. The docs should state more bluntly that capped samples can still degrade differential acceptance and reach-boundary accuracy.
- `MesonDecayToLLP n_strata`: The description includes useful advice, but the default/reference language makes `16` feel acceptable. For precision reach contours, especially the upper edge, it should recommend `64` or expose a named mode like `accuracy="contour"`.
- `DecayInVolumeVsCoupling acceptance`: For photons, the available `photon` mode is described as collinear, while the task required two-body photons. I correctly used `two_track` with zero daughter masses, but that is an easy trap. A `two_body` or `two_photon` acceptance alias would be clearer.
- `DecayInVolumeVsCoupling n_target`: It warns when a band runs off the coupling grid, but it does not warn when upstream event statistics or `n_strata` are likely inadequate for boundary precision.

2. **Unexpected behavior or output**

- `PythiaFromRunCard` returned a minimal response without the cross section even though the tool description shows cross-section data in the result. The cross section was in the manifest, so it was available, but the response differed from expectation.
- `DecayInVolumeVsCoupling` reported `band_bracketed=true` even for masses where the peak yield was below 3 and no exclusion existed. That is logically understandable as “not running off-grid,” but the wording can be misleading; a distinct `has_reach=false` would be clearer.
- The `photon` acceptance name suggested diphoton acceptance, but actually meant collinear light daughters. The description does say this, but the name is still misleading.

3. **Concrete changes**

- Add a pipeline-level `ReachScan` tool that consumes parent flux + spectra manifests and runs all masses/channels with consistent accuracy settings, producing `scan.csv` directly.
- Add `accuracy` presets to `MesonDecayToLLP`, e.g. `quick`, `yield`, `contour`, with documented defaults like `n_strata=16/32/64`.
- Add downstream diagnostics in `DecayInVolumeVsCoupling`: effective event count near the weak and strong boundaries, warnings for sparse accepted weighted samples, and a suggested rerun command/parameters.
- Rename or supplement `acceptance="photon"` with `acceptance="collinear"` and add `acceptance="two_body"` for isotropic two-daughter decays with arbitrary daughter masses.
- Include `sigmaGen_mb` directly in the `PythiaFromRunCard` response, matching the tool description.
- Make `HarvestForwardFlux` report an accuracy warning when `cap` is active and the user is likely doing geometric reach, not just total-rate estimates.

4. **Missing capability**

Yes: I wanted a **convergence/refinement tool**. Given existing yield JSONs and manifests, it should identify which masses/channels control the exclusion boundaries and recommend or execute targeted reruns with higher `n_strata`, larger parent caps, or more Pythia statistics. That would have directly addressed the failed yield and contour-accuracy stages.