# Blind usability rating (pre-grade)

8 - The tools covered the full physics pipeline cleanly with good provenance and diagnostics, with only some friction from needing many manual per-mass yield calls and limited batching.

---

**Audit**

The failed yield and contour stages were mostly driven by my methodology, not by missing physics capability in the tools. The main issue was insufficient statistics and sampling choices: I used `PythiaFromRunCard` with only `n_events=200000`, capped abundant species in `HarvestForwardFlux` at `cap=100000`, used `MesonDecayToLLP.n_strata=32` only for kaons and lower values for other parents, and used a 150-point coupling grid. Those choices were pragmatic for runtime, but they directly affect yield accuracy and especially the strong-coupling boundary.

The most likely tool/documentation change that would have prevented this is an explicit “reference-grade settings” recipe in the reach-chain docs, including recommended `n_events`, `cap`, `n_strata` by parent class, and `g_grid` density for contour grading. A second-best interface change would be a single orchestrating reach-scan tool that accepts the declared mass grid and target precision, then chooses sampling and batching settings itself.

Knowing the grade, I would revise my usability rating from **8 to 7**: the tools are powerful and mostly coherent, but it was too easy to produce a plausible, complete, reproducible result that was not precision-grade.

**Tool Critique**

1. **Confusing or error-prone areas**

- `MesonDecayToLLP.n_strata`: the description warned that the strong-coupling boundary improves with higher strata, but it did not make clear enough that this could dominate grading accuracy. I treated lower strata for non-kaon parents as acceptable; a reference-grade warning would have helped.

- `HarvestForwardFlux.cap`: the cap is statistically compensated, but the downstream contour accuracy still depends on retained event diversity. The parameter description explains unbiased normalization, but not how cap values affect reach-boundary variance.

- `DecayInVolumeVsCoupling.g_grid_path`: the tool accurately evaluates the supplied grid, but there is no guidance on grid density needed for contour extraction. My 150-point grid was reproducible but likely too sparse for accurate boundary interpolation.

- `PythiaFromRunCard.n_events`: the tool reports accepted events and cross section, but there is no precision diagnostic tying parent-channel counts, especially `Jpsi`/`psi2S`, to expected reach uncertainty.

2. **Behavior differing from expectations**

- `DecayInVolumeVsCoupling` was clear mechanically, but `acceptance="two_track"` performs stochastic daughter acceptance sampling. I expected seed-stable results, which it gave, but I underestimated how much finite daughter sampling and upstream event counts would matter for yield-distance grading.

- `HarvestForwardFlux` says capped samples preserve summed weights, which is true, but the output can look statistically “complete” while still being variance-limited for thin geometric/lifetime regions.

3. **Concrete changes**

- Add a “precision mode” or `target_accuracy_dex` option to the chain, especially for `MesonDecayToLLP` and `DecayInVolumeVsCoupling`, with warnings when sample size, cap, or strata are likely too low.

- Add a bundled driver like `ForwardReachScan` that consumes run card, parent list, mass grid, geometry, widths, and `N_int`, then batches spectra, LLP flux, yield scans, CSV, and contour diagnostics.

- In `DecayInVolumeVsCoupling`, emit contour-boundary diagnostics directly: lower/upper edge estimates, interpolation method, and warnings when grid spacing is too coarse near `N_sig=3`.

- In `HarvestForwardFlux`, report per-parent effective statistical precision or at least flag low-count channels that dominate open high-mass production.

4. **Missing capability**

Yes: I wished for a single tool to run the full reach pipeline with declared reproducibility settings and precision targets. The individual tools were strong, but manually coordinating Pythia statistics, caps, strata, coupling grids, and per-mass/per-search calls was the main source of avoidable accuracy loss.