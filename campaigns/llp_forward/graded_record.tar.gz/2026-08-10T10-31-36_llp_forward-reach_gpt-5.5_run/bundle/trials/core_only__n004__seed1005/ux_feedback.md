# Blind usability rating (pre-grade)

5 - Workable with real friction because the workspace lacked domain inputs beyond the prompt, so I had to build a self-contained simulation and make explicit approximations under time and sandbox constraints.