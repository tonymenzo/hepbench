# Blind usability rating (pre-grade)

5 - Workable, but the production-decay physics had to be implemented without domain-specific tooling or reference inputs, which introduced real friction and uncertainty.