# Blind usability rating (pre-grade)

8 - The tool chain covered the full physics workflow cleanly with good provenance and diagnostics, with only minor friction around batching many yield calls and manually managing grids/width inputs.

---

**Audit**

The failed `yield_distance`, `contour_lower`, and `contour_upper` stages were mostly my methodology, not a hard tool failure. I used `MesonDecayToLLP.n_strata=8` after the tool explicitly warned that the strong-coupling boundary needs finer decay-length sampling. That likely under-sampled the thin upstream parent-decay region driving the upper edge, and it also affected yield accuracy at graded points.

The main tool/documentation change that would have prevented it: make `MesonDecayToLLP.n_strata` default to the reference-grade value, or have `DecayInVolumeVsCoupling` emit a stronger fail/warning when consuming low-strata LLP files for reach-contour work.

Knowing the grade, I would lower my usability rating from `8` to `7`: the tools were capable, but the accuracy-critical sampling choice was easy to under-set for runtime reasons.

**1. Confusing Or Error-Prone**

- `MesonDecayToLLP.n_strata`: the description says low values are unbiased and gives accuracy guidance, but the practical grading impact was larger than I treated it. A “recommended for publication/reference reach: 64” default or warning would help.
- `DecayInVolumeVsCoupling.acceptance`: for photons, the tool offers `photon`, but its description says collinear light daughters. The task required two photons as straight-line daughters, so I used `two_track` with zero daughter masses. That was possible, but not obvious.
- `DecayInVolumeVsCoupling.partial_widths_ref_gev`: good interface, but it requires the caller to handle the above-threshold analytic continuation of the loop width. That is easy to get wrong if the prompt only writes the below-threshold form.

**2. Behaviour Versus Description**

- Prompt vector parents with `ctau_parent_m=0` still produced `n_strata`-multiplied records in `MesonDecayToLLP`. I expected prompt parents to collapse to one record per parent per mass. The output was valid, but inflated file sizes and runtime.
- `DecayInVolumeVsCoupling` handled low-yield/no-reach cases cleanly, but `band_bracketed=true` can be slightly misleading when the peak is far below threshold; it means the scan does not run off, not that a contour exists.

**3. Concrete Changes**

- Add `accuracy_profile`: `fast`, `standard`, `reference` to `MesonDecayToLLP`, setting `n_strata` and maybe caps consistently.
- Include `n_strata` provenance in each LLP file and have `DecayInVolumeVsCoupling` warn if it is below a recommended value for `n_target` reach scans.
- Add an explicit `acceptance="two_photon"` mode equivalent to two massless isotropic daughters.
- Add a high-level orchestration tool that takes masses, parents, geometry, coupling grid, and channels, then runs spectra, decay, yield, and scan consolidation consistently. The individual tools are good, but hand-orchestrating 20+ calls is error-prone.
- For prompt parents, avoid multiplying records by `n_strata`, or document why that is necessary.

**4. Missing Capability**

A combined “reach pipeline” tool would have helped most: one call to run all open parent channels and both searches with reference-grade defaults, while still writing the same manifests and intermediate files for audit.