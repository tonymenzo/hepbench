# Blind usability rating (pre-grade)

8 - The domain tools covered the full physics chain cleanly with strong provenance and diagnostics, with minor friction around many per-mass yield calls and filename/manifest conventions.

---

**Audit Of Failed Stages**

- `yield_distance`: Mostly my methodology. I used only `200k` Pythia events and `cap=100000` in `heptapod__HarvestForwardFlux`, which preserved normalization but left limited effective statistics for differential geometry/yield accuracy. The tool friction was that no tool estimated whether the generated sample and cap were adequate for the graded reach points.

- `contour_lower`: Mostly my methodology. The weak edge is production/statistics limited, and I did not run enough Pythia or uncapped parent statistics. `HarvestForwardFlux.cap` being easy to set low made the run tractable but noisier.

- `contour_upper`: Mostly my methodology, with some documentation/tool-interface friction. I used `n_strata=8` in `heptapod__MesonDecayToLLP` even though the tool explicitly warned the strong-coupling boundary benefits from much larger `n_strata`, especially around parent decays just before the absorber. A better default or stronger warning would likely have prevented this.

The single most useful change would be an automatic “reach-quality preset” or diagnostic that recommends `n_events`, `cap`, and `n_strata` for lower/upper contour accuracy before expensive downstream scans.

Knowing the grade, I would lower my usability rating from **8 to 7**: the tools are powerful and well connected, but they leave important precision-control choices too manual for a benchmark where accuracy, not just pipeline completion, is graded.

## 1. Confusing, Underdocumented, Or Error-Prone

- `heptapod__HarvestForwardFlux.cap`: The weight compensation is documented, but the precision consequence is easy to underappreciate. It preserves the mean, not the effective statistics needed for geometry-sensitive reach contours.

- `heptapod__MesonDecayToLLP.n_strata`: The description includes useful advice, but the default and low values make it too easy to produce a plausible-looking scan that fails the strong-coupling boundary.

- `heptapod__DecayInVolumeVsCoupling`: The output diagnostics say whether the coupling band is bracketed, which is good, but they do not estimate MC uncertainty or warn that the contour is sample-starved.

## 2. Behaviour Versus Expectation

- `DecayInVolumeVsCoupling` behaved as documented, but the “bracketed” diagnostic can give a false sense of completion. Bracketed does not mean accurate.

- `HarvestForwardFlux` capping behaved correctly, but because the output still reports clean summed weights, it is easy to miss that downstream tails can be noisy.

## 3. Concrete Changes

- Add a `precision_preset` option, e.g. `draft`, `standard`, `contour`, that sets or recommends `cap`, `n_strata`, and minimum event counts.

- Add uncertainty diagnostics to `DecayInVolumeVsCoupling`, especially effective sample size near the lower and upper `N_sig=3` crossings.

- Make `MesonDecayToLLP` emit a stronger warning when `n_strata < 16` and `n_target` reach contours will be computed downstream.

- Add a manifest-level checker that reads Pythia, harvest, meson-decay, and yield outputs and flags likely precision bottlenecks.

## 4. Missing Capability

A dedicated end-to-end reach driver would help: given masses, parents, geometry, widths, `N_int`, and target precision, it would run the full chain with adaptive statistics and produce `scan.csv`, contour summaries, and reproducibility metadata.