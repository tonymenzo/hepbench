# Blind usability rating (pre-grade)

5 - Workable with real friction because the workspace lacked model helper files and the production calculation required building a local approximation pipeline under tight tool and runtime constraints.