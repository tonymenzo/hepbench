# Blind usability rating (pre-grade)

5 - Workable with real friction: the workspace was sparse and I had to build a full reproducible simulation pipeline under time/runtime constraints without domain-specific helper tools.