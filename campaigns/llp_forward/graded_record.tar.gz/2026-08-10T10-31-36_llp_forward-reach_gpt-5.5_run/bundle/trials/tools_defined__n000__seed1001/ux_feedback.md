# Blind usability rating (pre-grade)

8 - The staged tools matched the workflow well and preserved normalization conventions, with the main friction being many manual per-mass yield calls instead of a single grid-level scan driver.

---

**Audit**

The failed yield and contour stages were mainly driven by my methodology, not a hard tool failure. I capped abundant parent fluxes at `cap=50000` in `heptapod__HarvestForwardFlux` and used `n_strata=16` in `heptapod__MesonDecayToLLP`; the tool description explicitly warned that the strong-coupling edge improves substantially with larger `n_strata`, and I optimized for runtime/file size rather than contour precision.

The most useful tool/docs change would be a single grid-level orchestration tool that runs `ProductionSpectrum -> MesonDecayToLLP -> DecayInVolumeVsCoupling` with precision targets, and warns or refuses when `cap`/`n_strata` are likely too low for the requested contour accuracy.

Knowing the grade changes my usability rating from **8 to 7**: the tools are capable, but it was too easy to make a plausible, reproducible scan that was under-sampled for the graded observables.

**Tool Critique**

1. **Confusing or error-prone**
   - `heptapod__HarvestForwardFlux.cap`: the compensation behavior is documented, but the accuracy impact on rare acceptance tails is easy to underestimate. I treated it as mostly harmless normalization-preserving thinning.
   - `heptapod__MesonDecayToLLP.n_strata`: the warning mentions strong-edge convergence, but it appears central enough that the default/interface should push harder toward `64` or expose an accuracy preset.
   - `heptapod__DecayInVolumeVsCoupling`: per-mass calls made it cumbersome to maintain consistent settings across 24 scans.

2. **Unexpected behavior**
   - No major mismatch, but `DecayInVolumeVsCoupling` reports `band_bracketed` cleanly while not diagnosing whether the upstream LLP sample is sufficiently precise for the contour edge.
   - The tools correctly preserve normalization, but their summaries emphasize summed weights and bracketing more than Monte Carlo precision of the final reach boundary.

3. **Concrete changes**
   - Add an `accuracy_target` or `mode: draft|production|contour` parameter that recommends or sets `cap`, `n_strata`, and audit settings.
   - Add a batch/grid wrapper for all masses and searches, consuming manifests directly.
   - Emit effective uncertainty estimates for yields and boundary locations, especially for the strong-coupling edge.
   - Make `n_strata=64` the documented production default for reach contours, even if `16` remains the quick default.

4. **Missing capability**
   - A manifest-driven end-to-end reach-scan tool would have helped most: it should read the parent/spectrum/LLP manifests, assemble open channels per mass, run both visible searches, write `scan.csv`, and produce contour diagnostics.