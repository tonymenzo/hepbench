# Blind usability rating (pre-grade)

8 — Smooth overall: Pythia, NumPy/SciPy, and LaTeX were all present and fast, and the task was well-specified enough to execute autonomously; the only real friction was the one-off `nohup &` backgrounding misfire and having to hunt down a float32 precision bug, both self-inflicted rather than environmental.