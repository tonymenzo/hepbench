# Blind usability rating (pre-grade)

**8/10** — The heptapod chain was well-designed for this workflow: grid modes, glob-based flux concatenation, the `partial_widths_ref_gev`+`visible_channels` interface that derives BR and total width self-consistently, and built-in diagnostics (band bracketing, n_strata advice, sigma_gen echo) removed nearly every place a physics error could hide silently; the only real friction was having to hand-transcribe per-mass partial widths into 20 separate tool calls rather than passing a widths file the tool could consume.

---

## Audit against the grade

**yield_distance (FAIL).** Not tool friction — a methodology divergence I can name. For the diphoton search I deliberately chose `DecayInVolumeVsCoupling`'s `acceptance="two_track"` with `daughter_masses_gev=[0,0]` over the dedicated `acceptance="photon"` mode, reasoning that "both photons must reach it" meant an isotropic two-body geometry rather than the collinear line-of-flight approximation. If the reference uses `photon`, that's a systematic per-point acceptance offset consistent with the ~0.48 dex the stage reports, even while the N=3 crossings stay close (band edges agreed to 0.005–0.03 dex). So the yield *magnitude* moved but the *contour* barely did — exactly the pattern in the feedback.

**contour_lower / contour_upper (FAIL).** These read as tight-threshold near-misses rather than a wrong method: the same acceptance-mode shift moves the whole N(g) curve slightly, and the strong-edge is the sample-starved one. My one real lever there was `n_strata` — I raised it to 64 only for the finite-lifetime K/D/Ds and left vectors at 16 (correct, they're prompt), so the K-dominated edges were as sharp as the tool offered; the residual is the acceptance convention plus intrinsic thin-sliver statistics.

**Single change that would most likely have prevented it:** documentation in `DecayInVolumeVsCoupling` stating which acceptance mode is the canonical diphoton treatment (and that `two_track [0,0]` vs `photon` differ at the tens-of-percent level), so I'd have matched the reference instead of picking the "more faithful" one and diverging.

**Does the grade change my rating?** Slightly — from 8 to **7**. The failures weren't friction, but the acceptance-mode ambiguity is a genuine documentation gap that cost real accuracy, and it's the kind of silent convention mismatch these tools otherwise work hard to prevent.

## Tool critique

1. **Confusing / error-prone.** The acceptance selector in `DecayInVolume*` (`two_track` vs `photon`) is the one place the interface let me make a defensible-but-wrong choice with no signal. For a two-photon final state both modes are plausible and the description frames `photon` as "collinear light daughters" without saying it *is* the intended diphoton-search model or quantifying the difference vs `two_track [0,0]`. Everything else (the `partial_widths_ref_gev`+`visible_channels` self-consistency, `grid_diagnostic` band bracketing, `sigma_gen` echo, `n_strata` advice string) actively prevented errors.

2. **Behaviour vs description.** No real surprises. `two_track` with `daughter_masses_gev=[0,0]` was accepted and ran without complaint — I'd have welcomed a warning like "photon final state detected; consider acceptance='photon'" given the tool clearly knows both modes exist.

3. **Interface / default / doc changes.**
   - Document (and ideally emit) the physical difference between `photon` and `two_track [0,0]`, and state which the standard γγ reach uses.
   - Let `DecayInVolumeVsCoupling` read `partial_widths_ref_gev` from a **per-mass file** (keyed by `m_phi`), the same way it already accepts `g_grid_path`/`events_paths_glob`. I hand-transcribed 20 sets of two widths into 20 calls; a widths file the tool consumes would remove the one transcription-error surface left in the chain.

4. **Wished-for capability.** A batch reach driver: given the mass grid, a geometry, a widths file, and a g-grid, iterate the per-mass `DecayInVolumeVsCoupling` (auto-globbing the parent fluxes per mass) and emit the flat `search,m_phi,g,nsig` table plus extracted band edges in one call. That would have collapsed my 20 manual invocations and the CSV-assembly script into a single reproducible step — and, incidentally, forced one consistent acceptance convention.