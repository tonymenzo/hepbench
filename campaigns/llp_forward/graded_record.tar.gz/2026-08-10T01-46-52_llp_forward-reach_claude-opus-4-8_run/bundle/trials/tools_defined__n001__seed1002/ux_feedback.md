# Blind usability rating (pre-grade)

**9/10** — The heptapod tools formed a clean, composable chain where each step's output fed the next with sensible conventions (g²-stripping, glob-based channel concatenation, grid modes, and built-in normalization/band-off-grid diagnostics), and the only minor friction was having to manually carry per-mass partial widths and mass-tag filename formats between stages.

---

## Audit against the grade

**contour_upper (FAIL) — my methodology, not tool friction.** The strong-coupling edge is set by the decay-length sampling density, and `MesonDecayToLLP`'s `n_strata` return message stated this explicitly: *"the STRONG-coupling reach boundary is reproducible to ~4.8% at K=16, vs ~1.0% at K=64… raise n_strata to 64 if you are locating the upper edge of a reach contour."* I read that and still ran the light parents (K, D, Ds, ρ, ω, φ) at `n_strata=16` to bound record counts — and those are exactly the parents that set the dimuon upper edge at m=0.23. I reserved 64 for charmonia, which don't drive that island. This is a self-inflicted failure against a clear warning.

**yield_distance (FAIL) — most likely the same root cause.** contour_lower passed at high accuracy and no_spurious_reach passed, so the flux normalization and band shape were right; the accuracy shortfall is concentrated where decay-length sampling bites (near/above the peak, which the declared coupling points probe). The same `n_strata=16` choice is the plausible driver.

**Single change that would most likely have prevented both:** run `n_strata=64` for *all* parents (the fix was one parameter value on 6 calls). On the tool side, a higher default (or making the advice string a pre-run warning rather than a post-run note) would have flipped my decision.

**Does this change my rating?** Slightly down, 9 → **8**. The tools are still smooth, but the `n_strata=16` default paired with cost framing ("record count scales linearly with K") actively nudged me toward the wrong tradeoff for a reach study whose graded observable is the lifetime-limited edge.

## Tool critique

**1. Confusing / error-prone.**
- `MesonDecayToLLP:n_strata` — default 16 is tuned for yield/weak-edge convergence, but the headline deliverable of a reach study is the contour, and the upper edge needs ≥64. The guidance exists but arrives *after* the run and is framed around cost, so it reads as "16 is fine, 64 is optional" when for this task it was load-bearing.
- Per-mass `partial_widths_ref_gev` had to be hand-carried from `physics.py` into 20 `DecayInVolumeVsCoupling` calls as literal floats — transcription-prone; one wrong exponent would silently rescale a mass's lifetime.
- Filename mass tags (`m0.2050` 4-decimal) had to be reverse-engineered from `MesonDecayToLLP` output to build the `events_paths_glob` per mass.

**2. Behaviour vs. expectation.**
- `n_strata` being *unbiased at any value* (per docs) led me to treat it as a pure variance knob I could economize on; in practice the variance it controls IS the graded observable at the strong-coupling edge. The docs say this, but the "unbiased" framing understates that the edge is sample-starved regardless of bias.
- Nothing else surprised me — normalization, glob concatenation, and the g²-portal reweighting all behaved exactly as described (the forward J/ψ rate matching the skill's reference was a great confidence signal).

**3. Interface/default/doc changes.**
- Raise the `n_strata` default to 32–64, or emit a *warning* (not a note) when a reach scan is downstream: "you are running `DecayInVolumeVsCoupling` with n_int and n_target — the upper contour edge needs n_strata≥64."
- Let `DecayInVolumeVsCoupling` accept a `partial_widths_grid` file keyed by mass (like the g-grid already supports `g_grid_path`), so the width table is passed once instead of retyped 20×.
- Have `MesonDecayToLLP` grid mode echo the exact glob pattern that will select all its output masses, to remove the filename-format guesswork.

**4. Missing capability.**
- A single "reach scan" orchestrator that takes the mass grid + geometry + width table and fans out `MesonDecayToLLP`→`DecayInVolume` across all masses/channels, auto-selecting `n_strata` per the target observable — would have removed both the 20-call bookkeeping and the n_strata pitfall that cost me the two stages.