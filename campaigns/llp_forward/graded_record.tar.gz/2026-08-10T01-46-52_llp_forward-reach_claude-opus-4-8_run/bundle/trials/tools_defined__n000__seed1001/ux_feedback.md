# Blind usability rating (pre-grade)

**8/10** — The tool chain was well-factored and self-documenting (open/closed handling across the mass grid, `g²`-stripped portal reweighting, glob-based multi-parent concatenation, and helpful diagnostics like `band_runs_off_high` and per-factor normalization breakdowns), with the only real friction being that the coupling grid had to be manually widened after the fact to bracket the very-large-flux diphoton bands.

---

## Audit against the grade

**Score 0.98 — the two FAILs are `yield_distance` and `contour_upper`.**

**`contour_upper` (strong-coupling / lifetime-limited edge):** This was a methodology choice, not tool friction. The `MesonDecayToLLP` tool *explicitly warned me*: its `n_strata_advice` said the strong-coupling boundary is reproducible to ~2.1% at `n_strata=32` vs ~1.0% at `n_strata=64`, and that raising it "only for the small heavy-flavour fluxes is cheap." I chose 32 as a blanket value. The upper edge is the sample-starved observable (a thin sliver of the parent decay-length distribution just upstream of the absorber), so it is exactly where I should have spent the extra strata. The single most preventive change was in my hands: `n_strata=64` (or higher for K/charm). So this is **my methodology**, with the tool having done its part via a clear advisory.

**`yield_distance` (primary accuracy stage):** Harder to attribute, and the grader's own note concedes it is comparing at the reference's declared points via my log-log interpolation. My yields depend on the same strata sampling (affects the lifetime factor) plus my 20-points/decade `g` grid, which forces interpolation at the reference's declared couplings. A denser `g_grid` and finer strata would both have tightened this. Partly methodology (grid density, strata), partly just interpolation loss that any grid incurs.

**Single change that would most help:** default `n_strata` higher (or an adaptive default keyed to the flux size) in `MesonDecayToLLP` — since the tool already knows the reach-edge sensitivity, baking it into the default would have fixed both FAILs without me having to read the advice and act on it.

**Does the grade change my rating?** Slightly down, from 8 to **7**. The tools were genuinely smooth, but in hindsight the strata knob is the dominant accuracy lever and I under-set it despite a correct in-band warning; a better default would have carried a non-expert to a higher score.

## Tool critique

1. **Confusing / error-prone.** Little was outright confusing. The sharpest nit: `MesonDecayToLLP`'s `n_strata` is *the* accuracy control for the strong-coupling reach edge, but its default (16) and my chosen 32 both under-serve that edge — and nothing forces the issue at call time; the advice arrives *after* the run in `n_strata_advice`. The `DecayInVolumeVsCoupling` "width exceeds mass: Gamma reaches 9 GeV at g=10" warnings were slightly alarming but harmless (they fired only because I widened the grid to bracket bands; those high-g points carry zero yield).

2. **Behaviour vs. description.** No real surprises. `HarvestForwardFlux` folding + 0.5 weight, the `g²`-stripped portal reweighting, and glob-based multi-parent concatenation all behaved exactly as documented. `DecayInVolumeVsCoupling`'s `band_runs_off_high` diagnostic correctly caught my initial too-narrow grid — that was the system working as intended.

3. **Interface/default changes.**
   - Make `n_strata` default higher, or **adaptive**: the tool knows each flux's record count, so it could auto-raise strata for the small heavy-flavour channels where the upper edge lives. At minimum, surface the strata advisory *before* committing a large grid run.
   - `DecayInVolumeVsCoupling` could **auto-extend or recommend a `g` range** given `n_target`, rather than only reporting `band_runs_off_high` after a full scan — I had to rerun all 12 diphoton masses to bracket.
   - A note in `DecayInVolumeVsCoupling` docs that yield accuracy at *specific declared couplings* is limited by the caller's `g_grid` density (interpolation loss) would nudge toward finer grids.

4. **Missing capability.** A tool that, given the geometry, flux, and `n_target`, **returns the reach-band edge couplings directly** (root-finding on `N_sig(g)=N*` with adaptive refinement and adaptive strata near the lifetime-limited edge) would target exactly the two graded contour observables far better than a fixed log grid interpolated after the fact.