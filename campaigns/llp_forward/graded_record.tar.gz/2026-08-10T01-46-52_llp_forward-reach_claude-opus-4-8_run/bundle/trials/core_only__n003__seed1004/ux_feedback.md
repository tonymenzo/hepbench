# Blind usability rating (pre-grade)

8 — The environment was smooth: Pythia8 bindings, numpy/scipy/matplotlib, and pdflatex all worked out of the box, letting me run the full generate→compute→plot pipeline; the only real friction was minor sandbox quirks (`ps` blocked, `nice` warnings, and a false-positive permission block on deleting `report.aux`).