# Blind usability rating (pre-grade)

**8/10** — The tools formed a clean, well-factored chain (spectrum → flux → decay → yield) with excellent guardrails: grid modes, glob-based channel concatenation, `partial_widths_ref_gev`+`visible_channels` deriving BR to prevent width/BR drift, auto parent lifetimes, and band-off-grid warnings that caught my too-narrow coupling range; the only real friction was that the widened diphoton grid required a full re-run of all 12 mass points to keep the CSV on one consistent grid, and passing `n_int=2.7e18` as a literal integer felt awkward.

---

## Audit against the grade

**yield_distance (FAIL, primary accuracy).** Not tool friction — methodology. The 48 graded points span the band, and the region most likely to have dragged the distance is the strong-coupling side, where my yields are set by the short-lifetime tail. Two of my choices starved that tail: (a) `MesonDecayToLLP` `n_strata=32` rather than 64, and (b) only $3\times10^5$ Pythia events, which left charm/charmonium fluxes thin ($J/\psi$ 686, $\psi(2S)$ 49 forward parents). Neither is a tool defect; both were my calls.

**contour_upper (FAIL, lifetime-limited edge).** Same root cause, and this one the documentation explicitly warned me about. `MesonDecayToLLP` returned, on every call: *"Raise n_strata to 64 if you are locating the upper edge of a reach contour… raising it only for the small heavy-flavour fluxes is cheap."* I read that, judged 32 "a good balance," and shipped it. The upper edge is exactly the sample-starved sliver of the parent decay-length distribution that `n_strata` controls. This is a self-inflicted miss.

**Single change that would most likely have prevented it:** use `n_strata=64` (as advised) — ideally the tool would *auto-refine* `n_strata` for the small heavy-flavour fluxes where it's cheap, instead of leaving a uniform default that the caller must override per-edge.

**Does the grade change my rating?** No — I'll hold **8/10**. The failures trace to my methodology on parameters the tools documented well; that's evidence the tools communicated correctly, not that they were hard to use.

## Tool critique

**1. Confusing / error-prone.**
Very little. The sharpest edge: `n_strata` has real, asymmetric consequences (fine on the weak edge at 32, coarse on the strong edge) but its default and my one-time choice silently propagate through 8 decay calls and 20 yield calls. The cost of being wrong only surfaces at grading. The `DecayInVolumeVsCoupling` `n_int` also had to be passed as a bare integer `2700000000000000000`, which is easy to fat-finger versus `2.7e18`.

**2. Behaviour vs. description.**
Matched expectations throughout. `sum_weights`/`inputs` echoes let me confirm no parent channel was dropped, and the band-off-grid warning correctly flagged my initial $g\le10^{-2}$ diphoton grid as truncated — that saved a real error. The width/BR consistency via `partial_widths_ref_gev`+`visible_channels` behaved exactly as documented.

**3. Interface/default/doc changes.**
- Make `n_strata` edge-aware: either default to 64 for the low-statistics heavy-flavour channels, or expose an `auto` mode that refines until the strong-edge yield stabilises. The current uniform default quietly under-resolves the graded upper contour.
- Surface the `n_strata` advice in the *parameter description*, not only the response note, and state plainly "this controls the STRONG-coupling contour accuracy" so the trade-off is visible before the call, not after.
- Accept `n_int` in scientific-notation string form, or echo it back in a human-readable form to guard against digit-count errors.

**4. Missing capability.**
A convergence/stat-uncertainty reporter: given a flux, tell me the effective sample size per (mass, edge) and a suggested `n_strata`/`n_events` to hit a target contour precision. I had to eyeball "686 $J/\psi$ parents is probably fine" — a tool that quantified the resulting reach-edge uncertainty would have flagged the strong edge as under-resolved before grading did.