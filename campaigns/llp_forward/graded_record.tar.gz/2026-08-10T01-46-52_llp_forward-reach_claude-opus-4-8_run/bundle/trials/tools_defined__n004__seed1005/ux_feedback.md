# Blind usability rating (pre-grade)

**8/10** — The heptapod reach-chain tools were well-designed and composable: grid modes, glob-based channel concatenation, `partial_widths_ref`/`visible_channels` that derive BR internally, and built-in band-bracketing diagnostics (which caught my too-narrow g-grid) all removed friction; the only minor nit was having to pass the same per-mass partial widths inline across 20 calls rather than referencing a single shared file.

---

## Audit against the grade

**contour_upper (FAIL) — my methodology, not tool friction.** The strong-coupling edge is set by parents decaying in a thin sliver just upstream of the absorber, sampled by `MesonDecayToLLP`'s `n_strata` parameter. The tool's own `n_strata_advice` field told me explicitly: "~2.1% at K=32, ~1.0% at K=64… Raise n_strata to 64 if you are locating the upper edge of a reach contour; record count scales linearly, so raising it only for the small heavy-flavour fluxes is cheap." I read this, chose 32 uniformly, and judged it adequate. That was the wrong call — the failing edge is exactly the observable the advice named. **Single change that would have prevented it:** rerun the charm/charmonium channels (the sample-starved fluxes) at `n_strata=64` or higher; the tool even told me it was cheap to do selectively.

**yield_distance (FAIL) — mostly methodology, harder to pin on a tool.** This grades absolute yield at the reference's declared couplings. My most likely culprit is flux normalization: I flagged during the run that my harvested forward $J/\psi$ rate ($1.2\times10^{-3}$/collision in the $\theta<0.05$ cone) sat *above* the skill's quoted $1.07\times10^{-3}$ total, which I rationalized rather than investigated. If charmonium (and possibly charm) flux is systematically high, the high-mass yields drift. There's no single tool parameter that caused this — it's a validation step I skipped. A contributing factor is that I ran only one Pythia seed; a second seed would have exposed statistical vs. systematic offset.

**Does the grade change my rating?** No — it stays **8/10**. Both failures trace to my choices, and in the `n_strata` case the tool had already surfaced the exact guidance I needed. That's the opposite of tool friction; it's me under-weighting good in-band documentation.

## Tool critique

**1. Confusing / error-prone.**
Genuinely little. The main trap I nearly fell into and the grader confirmed matters: `n_strata` in `MesonDecayToLLP` has a benign-sounding default (16) and is unbiased at any value, so it *reads* like a pure variance/cost knob — but it silently controls accuracy of one specific physics boundary (the lifetime-limited upper contour). The advice string is excellent but arrives *after* the call, in the result, not in the parameter description where I'd read it *before* choosing.

**2. Behaviour vs. expectation.**
`HarvestForwardFlux` output matched its description mechanically, but nothing in the tool cross-checks the harvested rate against a physical expectation. The `note` field warns about `sigma_inel` coherence but not about, e.g., a forward charmonium rate landing above the plausible total — the kind of sanity check that would have caught my likely normalization drift.

**3. Concrete changes.**
- Move the `n_strata` "raise to 64 for the upper/strong-coupling contour" guidance from the *returned* `n_strata_advice` into the *parameter doc* itself, and consider defaulting higher (or auto-raising) for small heavy-flavour fluxes where the cost is negligible.
- Have `DecayInVolumeVsCoupling` emit a per-edge sampling-adequacy flag (e.g. "strong-coupling edge supported by only N effective parent-decay samples") so the sample-starved boundary announces itself instead of failing silently downstream.
- `HarvestForwardFlux` could optionally print a species rate per collision next to a reference band, flagging outliers.

**4. Missing capability.**
A lightweight statistical-uncertainty estimate on `N_sig(g)` (e.g. effective sample size / bootstrap band per grid point), so I could *see* which contour edges were MC-limited rather than inferring it from record counts. That single output would have told me the upper edge was under-sampled before the grader did.