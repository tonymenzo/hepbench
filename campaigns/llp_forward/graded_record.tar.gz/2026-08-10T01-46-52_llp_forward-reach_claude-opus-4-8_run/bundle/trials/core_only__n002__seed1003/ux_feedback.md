# Blind usability rating (pre-grade)

8 — The environment had everything I needed (Pythia 8 with Python bindings, numpy/scipy/matplotlib, LaTeX, PDF rasterizers) and the background-task workflow let me parallelize flux generation with development, with the only real friction being the sleep/wait ergonomics and a stale-file race when a scan opened a still-finalizing npz.