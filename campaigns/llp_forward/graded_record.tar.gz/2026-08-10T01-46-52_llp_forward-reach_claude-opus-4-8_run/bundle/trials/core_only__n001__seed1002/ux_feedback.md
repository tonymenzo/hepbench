# Blind usability rating (pre-grade)

8 — The environment was smooth and well-provisioned (Pythia, numpy, scipy, matplotlib, LaTeX all present) and the physics spec was precise enough to execute autonomously; minor friction only from discovering the g-grid needed extending twice to capture the diphoton upper boundary and the occasional working-directory reset in Bash.