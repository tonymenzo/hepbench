# Blind usability rating (pre-grade)

8/10 — The end-to-end physics workflow was well covered and auditable, with minor friction from Pythia call timeouts, verbose outputs, and invalid closed-channel calls not being flagged as tool errors.

---

## Audit of failed stages

- **`yield_distance` — primarily my methodology.** I used `HarvestForwardFlux(cap=10000)` despite the 100,000 default, reducing abundant-parent kinematic statistics, and only 150,000 Pythia events after `PythiaFromRunCard` repeatedly hit its 300-second timeout. I also used `MesonDecayToLLP(n_strata=32)`. These choices traded accuracy for runtime and storage without a quantitative convergence study.

- **`contour_lower` — primarily my methodology, with some tool friction.** The weak-coupling edge is production-statistics limited. My 10,000-record species cap and modest Pythia sample were the likely causes. `HarvestForwardFlux` preserved total weights under capping, but did not estimate the resulting acceptance-dependent variance or warn that the cap was inadequate for reach calculations.

- **`contour_upper` — clearly my methodology.** `MesonDecayToLLP` explicitly warned that `n_strata=32` gives roughly 2.1% reproducibility at the strong-coupling boundary and recommended 64 for contour work. I knowingly retained 32. Since the upper edge depends on the sparsely sampled parent-decay sliver immediately before shielding, this was not sufficient.

The single most useful change would be an end-to-end **target-precision mode**: accept a requested relative uncertainty on yields and both contour edges, adapt parent caps and decay strata accordingly, and report statistical errors or fail when the requested precision is unsupported. Knowing the grade, I would revise my usability rating from **8/10 to 7/10**: the tools are capable, but they make it too easy to produce plausible, fully validated-looking outputs without quantifying Monte Carlo accuracy.

## 1. Confusing, underdocumented, or error-prone areas

- `HarvestForwardFlux(cap=...)` documents weight compensation but does not quantify the loss of precision in downstream geometric acceptance. Preserving `sum_weights` can create false confidence because it does not preserve the accepted-spectrum precision.

- `MesonDecayToLLP(n_strata=...)` gave useful general convergence guidance, but not a sample-specific uncertainty. The warning was accurate; I should have acted on it.

- `DecayInVolumeVsCoupling(n_target=3)` checks coupling-grid coverage but not Monte Carlo precision at the crossings. A result can report `band_bracketed: true` while its boundary is statistically inaccurate.

- `PythiaFromRunCard(n_events=...)` has a fixed service timeout with no progress or resumable session. Both calls returned timeout errors even though one completed successfully and wrote its manifest shortly afterward.

- A kinematically closed dimuon call returned textual `"Error: Invalid Parameter"` inside normal content while `isError` remained `false`. That makes programmatic failure detection unreliable.

- The acceptance parameter `acceptance="two_track"` evaluates daughters at the fiducial midpoint. This is documented, but the interface name does not signal that approximation, and it cannot implement decay-point-dependent daughter geometry exactly.

## 2. Behaviour differing from expectations

- `PythiaFromRunCard` timed out while continuing to write output in the background. I expected either an atomic failure or a resumable running-session identifier, not an error response followed later by a valid manifest.

- Closed-channel `DecayInVolumeVsCoupling` calls appeared successful at the transport level (`isError:false`) despite containing a domain error and producing no yield file.

- The pipeline’s successful manifests, bracketed-grid diagnostics, schema validation, and nonnegative-yield checks suggested stronger numerical reliability than was actually achieved. None of those outputs exposed the uncertainty that ultimately failed the accuracy grading.

## 3. Recommended interface and documentation changes

- Add `target_relative_precision` or `precision_profile: "reach"` to the production and decay tools. It should choose or recommend `cap`, Pythia statistics, and `n_strata`.

- Have `HarvestForwardFlux` report effective sample size and weighted uncertainties in momentum/angular bins relevant to downstream acceptance, not only `sum_weights`.

- Have `DecayInVolumeVsCoupling` report uncertainty on each yield and on interpolated lower and upper \(N_{\rm sig}=N_*\) crossings.

- Make `n_target` trigger a precision audit in addition to a grid-coverage audit.

- Default `MesonDecayToLLP` to `n_strata=64` when a downstream contour threshold is declared, or emit a stronger machine-readable warning at 32.

- Make Pythia generation asynchronous or resumable, with progress, a session ID, and an explicit “completed after response timeout” recovery path.

- Return genuine tool errors with `isError:true` for closed visible channels, or return a structured successful result such as `{"status":"closed","yields":[...zeros...]}`.

- Rename midpoint acceptance modes explicitly, for example `two_track_midpoint`, and ideally add `two_track_decay_point`.

## 4. Missing capability

I most wanted a **pipeline-level convergence tool** that reruns selected stages at increased Pythia statistics, harvest cap, and decay strata, then compares yields and both reach boundaries. That would have directly identified the three failed accuracy stages before finalization.