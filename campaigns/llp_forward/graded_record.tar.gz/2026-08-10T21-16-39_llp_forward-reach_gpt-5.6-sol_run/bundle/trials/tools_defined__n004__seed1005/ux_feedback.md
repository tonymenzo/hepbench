# Blind usability rating (pre-grade)

8/10 — The end-to-end physics pipeline was well integrated and auditable, with minor friction from Pythia’s fixed call timeout, unexpectedly large event files, and verbose tool responses.

---

Revised usability rating: **7/10**. The workflow was coherent and auditable, but its multi-gigabyte intermediate representation and non-resumable Pythia timeout pushed me into accuracy-reducing sampling choices.

## Audit of failed stages

- **`yield_distance` — mostly my methodology, aggravated by tool friction.** I reduced Pythia from 300,000 to 100,000 events after `PythiaFromRunCard` timed out at 300 seconds, then capped abundant parent species at 10,000 in `HarvestForwardFlux(cap=10000)`. Those choices reduced flux and kinematic precision. The tool chain’s materialized JSONL design made higher statistics expensive: the final LLP directory was 3.9 GB even after these reductions.

- **`contour_lower` — primarily my methodology.** The weak boundary is production-limited, so the reduced Pythia sample and 10,000-parent cap directly hurt it. I should have generated multiple independently seeded chunks and combined normalized fluxes instead of accepting the smaller sample.

- **`contour_upper` — primarily my methodology.** I used `MesonDecayToLLP(n_strata=32)` despite its output explicitly stating that 64 strata are preferable for the strong-coupling boundary. The documentation was good here; I traded accuracy for storage and runtime.

The single change most likely to prevent all three failures would be a **streaming or fused `MesonDecayToLLP` + `DecayInVolumeVsCoupling` mode** that integrates parent-decay strata and detector acceptance without writing millions of repeated LLP JSONL records. That would make larger parent caps and `n_strata=64` practical.

## 1. Confusing or error-prone aspects

- `PythiaFromRunCard` has a fixed effective 300-second call timeout but does not document a recommended maximum event count, chunking strategy, or recovery procedure.
- A timed-out Pythia run left 232,694 events and a 2.44 GB file but no manifest, making the partial sample unusable because `sigmaGen` and finalized event counts were unavailable.
- `finals_only=true` was described as recording only `status==1`, yet the selected stable parents in the output had statuses such as 83. This may be intentional for particles made stable by the run card, but the description did not explain it.
- `HarvestForwardFlux(cap=...)` preserves total weight exactly, but the interface does not quantify the resulting kinematic-distribution uncertainty or recommend a cap based on reach accuracy.
- `DecayInVolumeVsCoupling(acceptance="photon")` is a collinear approximation, despite the name suggesting diphoton acceptance. Correct treatment required using `acceptance="two_track"` with `daughter_masses_gev=[0,0]`.
- The reach tool reports `band_bracketed=true` even when the peak never reaches `n_target`. That field is easy to misread without also checking the peak yield.

## 2. Behaviour differing from expectations

- `select_pids` reduced particle content but still produced roughly 1 GB per 100,000 events, much larger than expected for a narrow whitelist.
- The Pythia timeout occurred only after substantial work, with no resumable checkpoint or partial manifest.
- `MesonDecayToLLP` expands every retained parent into one JSON record per stratum for every mass. The description states that record count scales linearly, but the practical storage amplification across parents and masses was much more consequential than the interface conveyed.
- The tools’ returned summaries were often extremely verbose and sometimes truncated, making it harder to inspect the most important diagnostics consistently.

## 3. Concrete improvements

- Add native chunking and resume support to `PythiaFromRunCard`, writing a valid checkpoint manifest after each chunk.
- Add an option to store only selected particle four-vectors in a compact binary or columnar format such as Parquet.
- Fuse meson decay and reach evaluation, or store each parent once with reusable stratum metadata instead of materializing per-mass JSONL records.
- Let `HarvestForwardFlux` accept a requested statistical precision and choose or warn about the cap accordingly.
- Make `n_strata=64` the default when `n_target` or a reach contour is requested; retain 16 or 32 only for exploratory yield scans.
- Rename `acceptance="photon"` to `collinear_photon` and add an explicit `diphoton_two_body` option.
- Return compact summaries by default with consistent fields: peak yield, target crossings, event count, effective sample size, and a Monte Carlo uncertainty estimate.
- Distinguish `band_bracketed`, `target_reached`, and `no_reach` explicitly.
- Provide convergence diagnostics by rerunning a small subsample at doubled parent cap or doubled `n_strata`.

## 4. Missing capability

I most wanted an **end-to-end convergence-aware reach scanner** that consumes parent fluxes directly, streams over masses and couplings, estimates Monte Carlo uncertainty on both contour edges, and automatically increases parent sampling or decay-length strata until a declared precision is met.