# Blind usability rating (pre-grade)

8/10 — Smooth overall, with minor friction from Pythia binding quirks, generator normalization checks, and extending the coupling range to enclose the reach bands.