# Blind usability rating (pre-grade)

8/10 — Smooth overall, with the main friction coming from building and validating the full physics simulation pipeline from an almost-empty workspace.