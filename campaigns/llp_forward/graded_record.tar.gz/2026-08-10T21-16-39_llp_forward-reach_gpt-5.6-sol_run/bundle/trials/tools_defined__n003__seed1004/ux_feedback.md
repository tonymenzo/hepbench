# Blind usability rating (pre-grade)

8/10 — The tools formed a coherent, reproducible end-to-end physics pipeline with strong provenance and diagnostics, though verbose outputs, large intermediate files, and a few acceptance/grid edge cases added minor friction.

---

## Audit of failed stages

- `yield_distance`: Mostly my methodology. I reduced `HarvestForwardFlux.cap` from 100,000 to 20,000 and used only 200,000 Pythia events to control storage. That increased production and acceptance Monte Carlo variance. The tools did not provide propagated uncertainties or a convergence test, so I could not tell whether the resulting deviations would exceed grading tolerances.

- `contour_lower`: Mostly my methodology. The weak boundary depends on production normalization and geometric acceptance, both degraded by the aggressive parent cap. `HarvestForwardFlux` preserved the mean weight but not statistical precision; its output did not quantify the effective sample size or uncertainty introduced by capping.

- `contour_upper`: Clearly my methodology. I used `MesonDecayToLLP.n_strata=16` despite its documentation explicitly warning that the strong-coupling boundary is only reproducible to roughly 4.8% at that setting and recommending 64 strata for approximately 1%. I prioritized disk usage over contour accuracy.

The single most useful change would be an adaptive, fused production-to-yield tool that avoids materializing \(N_{\rm parent}\times N_{\rm strata}\times N_{\rm mass}\) JSONL records and accepts an accuracy target such as `relative_precision=0.01`. It could automatically increase decay-length sampling near the shielding boundary and report convergence uncertainties.

Knowing the grade, I would lower my usability rating from 8/10 to 7/10: the pipeline is coherent and well documented, but obtaining precision-grade contours requires substantial manual resource/accuracy tradeoffs.

## 1. Confusing or error-prone aspects

- `MesonDecayToLLP.n_strata` exposed a consequential precision choice without enforcing or estimating convergence. The documentation warned about the strong-boundary error, but the tool still returned `status: ok` without a quantitative uncertainty attached to each yield or contour edge.

- `HarvestForwardFlux.cap` correctly compensates weights, but “sum of weights is preserved” can be mistaken for “accuracy is preserved.” The interface should report effective sample size and an estimated variance penalty after subsampling.

- `DecayInVolumeVsCoupling` had less detailed parameter documentation than `DecayInVolumeVsLifetime`, particularly for `acceptance`. I had to infer that `two_track` with daughter masses `[0,0]` was required for two resolved photons.

- `acceptance="photon"` sounds like the appropriate diphoton choice, but it only checks the collinear LLP trajectory. That name is potentially misleading for a requirement that both photons hit the detector.

- Below threshold, requesting `visible_channels=["mumu"]` with a zero partial width produced:

  > two-track acceptance requires m_phi > m1 + m2

  Returning a valid all-zero yield table would have made mass-grid automation cleaner.

## 2. Behaviour differing from expectations

- Grid mode was described as reusing flux and decay vertices efficiently, but it still materialized millions of repeated JSONL records across masses. The resulting multi-gigabyte intermediate tree forced an accuracy-versus-storage compromise.

- `grid_diagnostic.band_bracketed` could be `true` even where the peak never reached the target. This is logically defensible—no band runs off the grid—but the name suggests an actual exclusion band was found.

- Successful status and normalization diagnostics did not indicate whether Monte Carlo precision was sufficient for contour extraction. The outputs were operationally valid but not necessarily accurate enough for the primary grading metric.

## 3. Recommended interface and documentation changes

- Add `relative_precision`, `max_records`, or `accuracy_profile: "yield" | "lower_edge" | "upper_edge"` and choose sampling automatically.

- Report per-point statistical uncertainties, effective sample sizes, and estimated uncertainties on both \(N_{\rm sig}=3\) crossings.

- Make `n_strata=64` the reach-contour default, or emit a prominent warning when `n_target` is supplied with fewer strata.

- Replace repeated JSONL output with compressed columnar storage or stream LLP records directly into the coupling scan.

- Rename `acceptance="photon"` to `collinear_trajectory`, and add an explicit `two_body` acceptance applicable to arbitrary daughter masses.

- Treat kinematically closed visible channels as zero-yield results rather than errors.

- Distinguish diagnostics such as `target_reached`, `lower_edge_bracketed`, and `upper_edge_bracketed`.

- Document the precision implications of `HarvestForwardFlux.cap`, not only its unbiased normalization.

## 4. Missing capability

I most wanted an end-to-end convergence tool: given parent fluxes, spectra, geometry, mass grid, coupling grid, and a target precision, it would adaptively sample production vertices and two-body acceptance until both reach boundaries stabilize, while returning statistical error estimates without writing enormous intermediate event files.