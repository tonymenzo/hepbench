# Blind usability rating (pre-grade)

8/10 — The end-to-end physics chain was well designed and auditable, though verbose outputs, long-running calls, and midpoint-only acceptance introduced minor friction.

---

## Audit of failed stages

- **`yield_distance` — primarily my methodology.** I used only 200,000 Pythia events, capped abundant species at 10,000 records through `HarvestForwardFlux(cap=10000)`, and retained just 432 \(J/\psi\) and 34 \(\psi(2S)\) parents. Those choices left meaningful flux and kinematic Monte Carlo noise, especially at high mass. The tools reported counts but no statistical uncertainty, so I accepted an under-resolved sample.

- **`contour_lower` — primarily my methodology, exacerbated by missing diagnostics.** The production-limited boundary depends on the weighted parent spectrum. Aggressive harvesting caps and limited charmonium statistics affected it. `HarvestForwardFlux` preserved total weights under capping, but did not quantify the resulting uncertainty in downstream acceptance-weighted yields.

- **`contour_upper` — clearly my methodology.** I used `MesonDecayToLLP(n_strata=32)` even though its output explicitly warned that the strong-coupling edge continued improving at 64 strata. I should have rerun with at least 64 strata and checked boundary convergence across two seeds or resolutions.

The single most useful change would be an **adaptive convergence mode with uncertainty estimates** spanning `HarvestForwardFlux` and `MesonDecayToLLP`: given a target contour tolerance, it should increase cap/sample size and `n_strata` until both reach edges stabilize. Knowing the grade, I would revise my usability rating from **8/10 to 7/10**: the workflow is strong, but it makes a numerically under-converged result look fully validated.

## 1. Confusing or error-prone areas

- `HarvestForwardFlux(cap=...)` explains that weights are compensated, but that can suggest capping is harmless. It is unbiased only for inclusive normalization; downstream geometric and lifetime acceptance still acquire sampling variance. The tool should report effective sample size and uncertainty-relevant diagnostics per species.

- `MesonDecayToLLP(n_strata=...)` documents expected upper-edge precision, but the default of 16 and my choice of 32 are too easy to mistake for production-quality settings. Its warning was useful, but advisory rather than actionable.

- `DecayInVolumeVsCoupling.grid_diagnostic.band_bracketed` was `true` even for masses whose peak yield never reached three events. “Bracketed” is semantically misleading when no band exists; an explicit `has_reach` field is needed.

- The acceptance names are error-prone. `acceptance="photon"` means collinear daughters, not an actual isotropic two-photon decay. The physically appropriate choice was `acceptance="two_track", daughter_masses_gev=[0,0]`. A name such as `collinear_line_of_flight` would be clearer.

- The yield tool evaluates daughter acceptance at the fiducial midpoint. This is documented, but it is an approximation to the requested decay-point-dependent geometry and should be highlighted in the result as an accuracy limitation, not only as a convention.

## 2. Behaviour differing from expectations

- Capped harvesting preserved `sum_weights`, as promised, but the downstream result lacked any indication that acceptance-sensitive observables could still be noisy. The normalization looked exact while the reach was not.

- `band_bracketed=true` for cases with `peak.n_sig < 3` differed from the natural interpretation that an exclusion band had actually been bracketed.

- The tools produced deterministic yields and audits but no Monte Carlo error bars. Given the detailed accuracy claims in the descriptions, I expected enough diagnostics to determine whether my particular Pythia and parent samples met those claims.

## 3. Concrete interface and documentation changes

- Add `target_relative_precision` or `target_contour_dex` to the chain, with adaptive parent caps and decay strata.

- Have `HarvestForwardFlux` return per-species effective sample size, weighted kinematic uncertainties, and a warning when rare channels have too few parents for acceptance studies.

- Add a convergence option to `MesonDecayToLLP`, such as `n_strata_grid=[16,32,64]`, returning estimated boundary stability.

- Change the production default to `n_strata=64` when `n_target` reach contours are the downstream goal, or make the downstream yield tool reject low-strata inputs unless explicitly accepted.

- Add `has_reach`, `lower_crossing`, and `upper_crossing` directly to `DecayInVolumeVsCoupling`; reserve `band_bracketed` for an existing band with both crossings found.

- Rename `acceptance="photon"` and add explicit modes such as `isotropic_two_body_massless` and `isotropic_two_body_massive`.

- Allow acceptance to be integrated over the actual scalar decay position rather than evaluated only at the midpoint.

## 4. Missing capability

I most wanted an end-to-end **reach convergence and uncertainty tool** that reruns or reweights the same pipeline at larger Pythia samples, harvest caps, decay strata, and independent seeds, then reports uncertainty on \(N_{\rm sig}\) and both contour edges. That would have directly exposed all three failed grading stages before submission.