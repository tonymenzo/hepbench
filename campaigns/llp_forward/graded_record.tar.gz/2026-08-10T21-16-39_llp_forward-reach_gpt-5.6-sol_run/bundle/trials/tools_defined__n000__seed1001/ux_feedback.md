# Blind usability rating (pre-grade)

8/10 — The end-to-end physics workflow was well covered and auditable, with minor friction from large intermediate files, midpoint-only acceptance, and incomplete automatic provenance such as the Pythia version.

---

## Audit of failed stages

- `yield_distance`: Primarily my methodology. I reduced `HarvestForwardFlux.cap` from its 100,000 default to 10,000 for abundant parents and generated only 200,000 Pythia events. That controlled disk use but increased kinematic and acceptance variance, especially after geometric cuts. The tools preserved summed weights exactly, which does not imply that weighted momentum distributions were converged.

- `contour_lower`: Primarily my methodology. The weak boundary depends on production normalization and acceptance, so the reduced parent cap and limited generator statistics directly affected it. `DecayInVolumeVsCoupling.n_target` verified only that the band was bracketed; it did not estimate boundary uncertainty or detect insufficient upstream statistics.

- `contour_upper`: Mixed, but mostly my methodology. `MesonDecayToLLP.n_strata` documentation explicitly warned that 16 strata gave roughly 4.8% strong-boundary reproducibility. I increased `n_strata` to 64 only for kaons after seeing that warning, instead of performing a full-channel convergence study or using 64 for every relevant parent. The tool made the risk visible; I optimized resources too aggressively.

The single most useful change would be an adaptive, streaming reach tool that consumes parent flux and spectra directly, increases `n_strata` until both contour edges meet a requested precision, and avoids multi-gigabyte LLP JSONL files. With the grading result, I would revise my usability rating from 8/10 to 7/10: the chain is capable and well structured, but obtaining reliably converged contours requires more manual statistical judgment than the interface suggests.

## Tool critique

### 1. Confusing or error-prone areas

- `HarvestForwardFlux.cap` says the compensating weight preserves the summed yield, but it does not emphasize strongly enough that capping can degrade angular, energy, decay-position, and detector-acceptance distributions. No effective sample size or cap-induced uncertainty is reported.

- `MesonDecayToLLP.n_strata` provides useful generic convergence guidance, but not a result-specific uncertainty estimate. Its advice mentions that increasing strata for “small heavy-flavour fluxes is cheap,” which can encourage selective refinement even when a high-rate long-lived parent controls the contour.

- `DecayInVolumeVsCoupling.n_target` reports `band_bracketed`, but that is only a grid-range check. It can look like a contour-quality check even though it says nothing about Monte Carlo convergence.

- `DecayInVolumeVsCoupling` uses acceptance at the fiducial midpoint. This is documented, but it is an approximation to the requested condition at the actual decay point and deserves a more prominent warning in the result.

- The large JSONL interfaces make precision choices operationally expensive. Raising caps or strata multiplies both disk usage and subsequent parsing cost, encouraging under-sampling.

### 2. Behaviour differing from the description

- `PythiaFromRunCard(finals_only=true)` was described as retaining particles with `status==1`, but the output included stable harvested parents with statuses such as 83, 84, 86, and 91. This behaviour was useful for the task, but it did not match the literal description.

- `PythiaFromRunCard`’s returned summary omitted the documented cross-section block; the cross section was available only in its written manifest.

- The Pythia version was not recorded in the generated manifest, despite reproducibility guidance requiring it. I had to instantiate Pythia separately and read its startup banner.

- `HarvestForwardFlux` preserved `sum_weights` exactly after capping, which could misleadingly suggest the capped flux was fully equivalent. It is equivalent only for inclusive normalization, not necessarily for downstream acceptance-sensitive observables.

### 3. Recommended interface and documentation changes

- Add `target_relative_precision` or `target_boundary_precision_dex` to the decay and reach tools, with adaptive strata and convergence diagnostics for both weak and strong edges.

- Report effective sample size, weighted variance, and bootstrap/jackknife uncertainty after harvesting and at every yield point.

- Make `cap=0` or a statistically justified adaptive cap the default for reach calculations; otherwise emit a prominent warning when capped records feed a geometric acceptance calculation.

- Allow `MesonDecayToLLP` and `DecayInVolumeVsCoupling` to stream records directly between stages instead of materializing one JSONL per parent and mass.

- Add exact decay-position-dependent two-body acceptance, rather than evaluating daughters only at the volume midpoint.

- Include Pythia version, complete resolved settings, cross section, selected-status policy, and RNG information directly in both the response and manifest.

- Clarify that `band_bracketed` means only “the scan endpoints lie outside the excluded band,” not “the boundary is statistically converged.”

- Provide an automated convergence report comparing caps, generator subsamples, and `n_strata` values.

### 4. Missing capability

I most wanted a single end-to-end adaptive reach tool that accepted the run card, parent set, mass grid, geometry, widths, and precision target; streamed the stages internally; and returned yields, contour uncertainties, convergence diagnostics, and compact provenance without requiring multi-gigabyte intermediate files.