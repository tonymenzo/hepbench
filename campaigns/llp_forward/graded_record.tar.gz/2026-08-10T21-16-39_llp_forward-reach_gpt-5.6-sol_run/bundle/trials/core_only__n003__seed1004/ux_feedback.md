# Blind usability rating (pre-grade)

8/10 — Smooth overall, with solid local tooling and reproducibility, though the long Pythia run and a small numerical masking issue added minor friction.